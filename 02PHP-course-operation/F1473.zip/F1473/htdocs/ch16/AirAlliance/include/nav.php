<!-- 網站導覽列 -->    
<li id="submenu">
    <h2>選擇功能</h2>
    <ul>
        <li><a href="listitinerary.php">顯示訂票</a></li>
        <li><a href="processitinerary.php">線上訂票</a></li>
        <li><a href="flightinfo.php">航班訊息</a></li>
        <li><a href="scheduleinfo.php">航班行程</a></li>
        <li><a href="confirmreservation.php">確認訂票</a></li>        
    </ul>
</li>