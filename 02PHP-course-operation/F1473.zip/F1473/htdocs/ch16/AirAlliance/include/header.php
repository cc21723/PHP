<!-- 網站標頭內容 -->    
<div id="header">
    <div id="logo">
        <h1><a href="index.php">Air Alliance航空公司</a></h1>
        <h2><a href="index.php">從1430年服務至今</a></h2>
    </div>
    <!-- end div#logo -->
    <div id="menu">
        <ul>
            <li><a href="index.php">網站首頁</a></li>
            <li><a href="processitinerary.php">線上訂票</a></li>
            <li><a href="confirmreservation.php">確認訂票</a></li>
           
        </ul>
    </div>
    <!-- end div#menu -->
</div>