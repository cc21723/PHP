<!-- 網站註腳內容 -->   
<div id="footer">
    <p id="legal">Copyright &copy; 2021 AirAlliance航空公司版權所有</p>
    <p id="links"><a href="#">保密策略</a> | <a href="#">使用授權</a></p>
</div>

