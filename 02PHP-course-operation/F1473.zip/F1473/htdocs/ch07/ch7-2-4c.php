<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch7-2-4c.php</title>
</head>
</head>
<body>
<?php 
$a = array(34, 56);
$b = array(23.1, 56.5, 90.2);
echo array_sum($a);
echo "<br/>--------------------<br/>";
echo array_sum($b);
?>
</body>
</html>