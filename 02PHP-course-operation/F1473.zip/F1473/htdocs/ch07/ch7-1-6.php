<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch7-1-6.php</title>
</head>
<body>
<?php
// 使用const建立常數陣列
const FRUITS = array(
    "西瓜", 
    "草莓",
    "蘋果",
    "藍莓",
);
print_r(FRUITS);
?>
</body>
</html>
