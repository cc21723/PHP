<?php   
    define('DB_NAME', 'simplecms');
    define('DB_USER', 'root');
    define('DB_PASSWORD', 'A12345678');
    define('DB_HOST', 'localhost');

    define('DEFAULT_ADMIN_USERNAME', 'root');
    define('DEFAULT_ADMIN_PASSWORD', 'A12345678');
?>