<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch2-3.php</title>
</head>
<body>
<h2>Visual Studio Code編輯的PHP程式</h2><br/>
<?php
phpinfo();
?>
</body>
</html>
