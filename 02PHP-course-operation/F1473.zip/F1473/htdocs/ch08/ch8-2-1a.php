<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch8-2-1a.php</title>
</head>
<body>
<?php 
header("Location: http://www.hinet.net");
exit();
echo "使用header()函數轉址到其他網頁或PHP程式<br/>";
?>
</body>
</html>