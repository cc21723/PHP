<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch8-2-1.php</title>
</head>
<body>
<?php 
header("Location: ch8-1-2.php");
exit();
echo "使用header()函數轉址到其他網頁或PHP程式<br/>";
?>
</body>
</html>