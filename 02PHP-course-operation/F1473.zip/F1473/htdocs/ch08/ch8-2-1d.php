<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch8-2-1d.php</title>
</head>
<body>
<?php
header("Refresh:2;url=ch8-1-2.php");
?>
</body>
</html>