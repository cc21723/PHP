<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch8-2-1b.php</title>
</head>
<body>
<?php 
header("Location: http://localhost:8080/ch03/ch3-1-1.html");
exit();
echo "使用header()函數轉址到其他網頁或PHP程式<br/>";
?>
</body>
</html>