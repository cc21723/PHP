<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-3-1.php</title>
</head>
<body>
<?php 
// 指定布林變數值
$isPass = True;
$statusOn = true;
var_dump($isPass);
var_dump($statusOn);
?>
</body>
</html>