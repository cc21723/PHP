<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-2-2.php</title>
</head>
<body>
<?php 
// 變數與指定敘述
$std_name = "陳允傑";
$englishGrade = 85;   // 指定成整數
$no = "1234567";
$englishGrade = "65"; // 指定成字串
// 顯示變數的內容
print "姓名: " . $std_name . "<br/>";
print "學號: " . $no . "<br/>";
print "英文成績: " . $englishGrade;
?>
</body>
</html>