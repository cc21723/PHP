<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-4-4a.php</title>
</head>
<body>
<?php 
// 比較整數
echo 1 <=> 1; // 0
echo "<br/>";
echo 3 <=> 4; // -1
echo "<br/>";
echo 4 <=> 3; // 1
echo "<br/>";
// 比較字串
echo "x" <=> "x"; // 0
echo "<br/>";
echo "x" <=> "y"; // -1
echo "<br/>";
echo "y" <=> "x"; // 1
echo "<br/>";
?>
</body>
</html>
