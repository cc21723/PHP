<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-1-2.php</title>
</head>
<body>
// 註解的使用
<?php
// 顯示歡迎訊息
print "<h2>Hello World!</h2>";  // 使用print輸出
/*  顯示不同尺寸的
    歡迎使用訊息文字 */
print "<h3>PHP與MySQL網頁設計!</h3>";
print "<h4>PHP與MySQL網頁設計!</h4>";
?>
</body>
</html>