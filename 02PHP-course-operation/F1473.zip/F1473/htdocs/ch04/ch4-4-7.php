<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-4-7.php</title>
</head>
<body>
字串連接運算1: "ab". "cd" = <?php echo "ab" . "cd" ?><br/>
字串連接運算2: "PHP與MySQL網頁" . "設計" = 
        <?php echo "PHP與MySQL網頁" . "設計" ?><br/>
</body>
</html>