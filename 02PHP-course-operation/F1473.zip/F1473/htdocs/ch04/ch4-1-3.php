<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-1-3.php</title>
</head>
<body>
<?php 
// 太長的程式碼
print "<h2>對於太長的程式碼, " . 
                 "我們需要分成兩列.</h2>";
/* print "<h2>對於太長的程式碼, "  
                    "我們需要分成兩列.</h2>"; */
?>
</body>
</html>