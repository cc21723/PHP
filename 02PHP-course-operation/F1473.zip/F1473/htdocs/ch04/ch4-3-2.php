<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-3-2.php</title>
</head>
<body>
<?php 
// 指定整數變數值
$a = 5678;   $b = -1234;
$c = 0234;   $d = 0x1A;
$e = 0x3fc;
echo "5678 = $a<br/>";  // 顯示變數值
echo "-1234 = $b<br/>";
echo "0234 = $c<br/>";
echo "0x1A = $d<br/>";
echo "0x3fc = $e<br/>";
var_dump($a, $b, $c, $d, $e);
?>
</body>
</html>