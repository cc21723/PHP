<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-3-3.php</title>
</head>
<body>
<?php 
// 指定浮點變數值
$j = 2.345; $k = 1.2345e3; $l = 7E-4;
echo "2.345 = $j<br/>";  // 顯示變數值
echo "1.2345e3 = $k<br/>";
echo "7E-4  = $l<br/>";
var_dump($j, $k, $l);
?>
</body>
</html>