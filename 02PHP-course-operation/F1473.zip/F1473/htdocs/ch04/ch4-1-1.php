<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch4-1-1.php</title>
</head>
<body>
<?php
echo "PHP與MySQL網頁設計<br/>";
?>
<?php
echo "PHP與MySQL網頁"; echo "設計<br/>";
?>
<?php echo "PHP與MySQL網頁設計<br/>" ?>
</body>
</html>