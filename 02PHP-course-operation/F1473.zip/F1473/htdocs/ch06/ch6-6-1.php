<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ch6-6-1.php</title>
</head>
<body>
<?php
$x;
$x = $x + 1;
echo $x;
require "ch6-1-1.inc"; 
?>
</body>
</html>